
// FalaDublada.com - Protótipo inicial do site

import React, { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { motion } from "framer-motion";

const frasesExemplo = [
  {
    frase: "Eu sou seu pai.",
    video: "https://www.youtube.com/embed/Q2v4zT3zA-U?start=5&end=10",
  },
  {
    frase: "Com grandes poderes vêm grandes responsabilidades.",
    video: "https://www.youtube.com/embed/YZ0s2OdWakQ?start=3&end=9",
  },
  {
    frase: "É o ciclo sem fim!",
    video: "https://www.youtube.com/embed/L0AiN8vrn9Y?start=1&end=6",
  },
];

export default function FalaDublada() {
  const [busca, setBusca] = useState("");
  const [resultados, setResultados] = useState([]);

  const buscarFrase = () => {
    const filtrados = frasesExemplo.filter((item) =>
      item.frase.toLowerCase().includes(busca.toLowerCase())
    );
    setResultados(filtrados);
  };

  const mostrarAleatoria = () => {
    const aleatoria =
      frasesExemplo[Math.floor(Math.random() * frasesExemplo.length)];
    setResultados([aleatoria]);
  };

  return (
    <div className="p-4 max-w-2xl mx-auto">
      <h1 className="text-3xl font-bold text-center mb-6">FalaDublada.com</h1>

      <div className="flex gap-2 mb-4">
        <Input
          placeholder="Digite uma frase..."
          value={busca}
          onChange={(e) => setBusca(e.target.value)}
        />
        <Button onClick={buscarFrase}>Buscar</Button>
        <Button variant="secondary" onClick={mostrarAleatoria}>
          Aleatória
        </Button>
      </div>

      <div className="space-y-4">
        {resultados.map((item, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            <Card>
              <CardContent className="p-4">
                <p className="mb-2 font-medium">{item.frase}</p>
                <div className="aspect-video">
                  <iframe
                    className="w-full h-full"
                    src={item.video}
                    title="Frase dublada"
                    frameBorder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  ></iframe>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
